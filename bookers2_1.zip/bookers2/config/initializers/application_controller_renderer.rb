# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '4e7e060277b89b5e85ad6b42aedeb0fa2a7796c06134f9beca3d669664f4b224169f4d56f7caa4ad4fc86d9e3ba27b28e03b0df6fbbff773b549f887cf25c014'